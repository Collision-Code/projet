var _event_8h =
[
    [ "ObservableEvent", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2", [
      [ "GEOMETRIES_LOADED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2aaade0cc220d1bbaa420bfbf1d37291f1", null ],
      [ "CHARGES_LOADED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a57351b3ff3812c929b3ea807128fd922", null ],
      [ "FILE_SAVED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a543c45e83d39c0efd08df94300eff342", null ],
      [ "CALCULATIONS_FINISHED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a9b9f754e0859bdfc4cbd913a1b292721", null ],
      [ "EHSS_STARTED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a9bf100ca92b7c520724737b43f8b7082", null ],
      [ "PA_STARTED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2aeb16650785916fe0f5ae44406c6388a3", null ],
      [ "TM_STARTED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a983a633fb48a679ddbd7a54afafc860e", null ],
      [ "TRAJECTORY_NUMBER_UPDATE", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a183ad2d61f76f6faf83749aa3cfadfc6", null ],
      [ "EHSS_ENDED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a43b1bb501a4146ba57a7c39349cf63bd", null ],
      [ "PA_ENDED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a63bbee0838547de0f9dd129bd401d48a", null ],
      [ "TM_ENDED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a8ea63e54e8c677b4ce23f8eb55e8bd36", null ],
      [ "ONE_CALCULATION_FINISHED", "_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2a5b682ce8f873c936455dd6e874efc402", null ]
    ] ]
];
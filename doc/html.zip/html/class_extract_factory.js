var class_extract_factory =
[
    [ "~ExtractFactory", "class_extract_factory.html#a1f825ed6f43ae856923c2c42e4d11024", null ],
    [ "getReader", "class_extract_factory.html#a3afab5dea9679eed50f29485e25fa8e6", null ]
];
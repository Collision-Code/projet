var class_pdb_file_reader =
[
    [ "PdbFileReader", "class_pdb_file_reader.html#a85a27073ac71a822e292c57a3e5269f5", null ],
    [ "~PdbFileReader", "class_pdb_file_reader.html#a9dbfdd542657bc19c317fcb43dc53a41", null ],
    [ "getFileName", "class_pdb_file_reader.html#a0da63c17887e5814ca0e50b05135e148", null ],
    [ "loadResources", "class_pdb_file_reader.html#a0a9bb68c279db8af1b13e46665bae751", null ],
    [ "setFileName", "class_pdb_file_reader.html#add59a4eca367751e25fec7a562960a8e", null ]
];
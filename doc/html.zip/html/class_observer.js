var class_observer =
[
    [ "Observer", "class_observer.html#a19c43f80a38a332a6f694783df3c9835", null ],
    [ "~Observer", "class_observer.html#a450645e61c136826f09940a1334c7f34", null ],
    [ "update", "class_observer.html#a889668da0ef61f88abbfab4f4b0a6fed", null ]
];
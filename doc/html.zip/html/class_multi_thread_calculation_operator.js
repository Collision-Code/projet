var class_multi_thread_calculation_operator =
[
    [ "MultiThreadCalculationOperator", "class_multi_thread_calculation_operator.html#aad8a83bb85fb2cbb6cfc9fd46daca1b9", null ],
    [ "~MultiThreadCalculationOperator", "class_multi_thread_calculation_operator.html#a1fe872ad70aa9b66c7052e1156d80280", null ],
    [ "calculateTM", "class_multi_thread_calculation_operator.html#a2e4dc9f1f6f42a159e4ccb7e5973cbd7", null ]
];
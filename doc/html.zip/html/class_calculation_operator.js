var class_calculation_operator =
[
    [ "~CalculationOperator", "class_calculation_operator.html#a58a3bb976d90d7b2031c14431034694f", null ],
    [ "getCalculationState", "class_calculation_operator.html#aa8fcb93f774a605b38498f137f2da608", null ],
    [ "getResults", "class_calculation_operator.html#ad1f6e4615f84cb92f4d5626312f3d396", null ],
    [ "runEHSSAndPA", "class_calculation_operator.html#a3ba2d7368bdc3dc00249264b4d941833", null ],
    [ "runTM", "class_calculation_operator.html#a9b61bd8a7351ab69a33cfe85d61813c2", null ]
];
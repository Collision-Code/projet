var searchData=
[
  ['observableevent',['ObservableEvent',['../_event_8h.html#a8f03e7f7fae5a3e8131d7cd77cd926a2',1,'Event.h']]]
];

var searchData=
[
  ['geometrycalculator',['GeometryCalculator',['../class_geometry_calculator.html',1,'']]],
  ['globalparameters',['GlobalParameters',['../class_global_parameters.html',1,'']]]
];

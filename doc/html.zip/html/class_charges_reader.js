var class_charges_reader =
[
    [ "~ChargesReader", "class_charges_reader.html#aa7116cc0043e802cec191c05b6507485", null ],
    [ "getFileName", "class_charges_reader.html#ae154a34dfaf97335ed9cf7139a1e5a86", null ],
    [ "loadResources", "class_charges_reader.html#ae0b98d348b680298ee94a2bbe57b4042", null ],
    [ "setFileName", "class_charges_reader.html#ab4850fc35eb5843f53742a1de33fd81d", null ]
];
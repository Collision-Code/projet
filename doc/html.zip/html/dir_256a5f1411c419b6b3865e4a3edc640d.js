var dir_256a5f1411c419b6b3865e4a3edc640d =
[
    [ "ChargesReader.h", "_charges_reader_8h.html", [
      [ "ChargesReader", "class_charges_reader.html", "class_charges_reader" ]
    ] ],
    [ "ChgChargesReader.cpp", "_chg_charges_reader_8cpp.html", null ],
    [ "ChgChargesReader.h", "_chg_charges_reader_8h.html", [
      [ "ChgChargesReader", "class_chg_charges_reader.html", "class_chg_charges_reader" ]
    ] ],
    [ "ExtractFactory.h", "_extract_factory_8h.html", [
      [ "ExtractFactory", "class_extract_factory.html", "class_extract_factory" ]
    ] ],
    [ "ExtractResources.h", "_extract_resources_8h.html", [
      [ "ExtractResources", "class_extract_resources.html", "class_extract_resources" ]
    ] ],
    [ "FileReader.h", "_file_reader_8h.html", [
      [ "FileReader", "class_file_reader.html", "class_file_reader" ]
    ] ],
    [ "LogFileReader.cpp", "_log_file_reader_8cpp.html", null ],
    [ "LogFileReader.h", "_log_file_reader_8h.html", [
      [ "LogFileReader", "class_log_file_reader.html", "class_log_file_reader" ]
    ] ],
    [ "MfjFileReader.cpp", "_mfj_file_reader_8cpp.html", null ],
    [ "MfjFileReader.h", "_mfj_file_reader_8h.html", [
      [ "MfjFileReader", "class_mfj_file_reader.html", "class_mfj_file_reader" ]
    ] ],
    [ "MolFileReader.cpp", "_mol_file_reader_8cpp.html", null ],
    [ "MolFileReader.h", "_mol_file_reader_8h.html", [
      [ "MolFileReader", "class_mol_file_reader.html", "class_mol_file_reader" ]
    ] ],
    [ "PdbFileReader.cpp", "_pdb_file_reader_8cpp.html", null ],
    [ "PdbFileReader.h", "_pdb_file_reader_8h.html", [
      [ "PdbFileReader", "class_pdb_file_reader.html", "class_pdb_file_reader" ]
    ] ],
    [ "StdExtractFactory.cpp", "_std_extract_factory_8cpp.html", "_std_extract_factory_8cpp" ],
    [ "StdExtractFactory.h", "_std_extract_factory_8h.html", [
      [ "StdExtractFactory", "class_std_extract_factory.html", "class_std_extract_factory" ]
    ] ],
    [ "StdExtractResources.cpp", "_std_extract_resources_8cpp.html", null ],
    [ "StdExtractResources.h", "_std_extract_resources_8h.html", [
      [ "StdExtractResources", "class_std_extract_resources.html", "class_std_extract_resources" ]
    ] ],
    [ "XyzFileReader.cpp", "_xyz_file_reader_8cpp.html", null ],
    [ "XyzFileReader.h", "_xyz_file_reader_8h.html", [
      [ "XyzFileReader", "class_xyz_file_reader.html", "class_xyz_file_reader" ]
    ] ]
];
var class_std_extract_factory =
[
    [ "StdExtractFactory", "class_std_extract_factory.html#a91404edffdce79e7d6701c26631102b0", null ],
    [ "~StdExtractFactory", "class_std_extract_factory.html#aac4dcd68d4b0a91501ba963bdf8ac571", null ],
    [ "getReader", "class_std_extract_factory.html#a60aa706973b87b9f9e8364a414b6185e", null ]
];
var class_extract_resources =
[
    [ "~ExtractResources", "class_extract_resources.html#af1c8c0052e6e25d7aa95c8033acc3739", null ],
    [ "getGeometriesFromFile", "class_extract_resources.html#a75a92ba5957bc5447cebd10dc325df94", null ]
];
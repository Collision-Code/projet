var class_xyz_file_reader =
[
    [ "XyzFileReader", "class_xyz_file_reader.html#ae01e82a1ccd27ad909dd27c8741bca2c", null ],
    [ "~XyzFileReader", "class_xyz_file_reader.html#a6f0c4cf1d7c35678aba65103f6f521b1", null ],
    [ "getFileName", "class_xyz_file_reader.html#a64738276b89b3c7542fadae458d1a589", null ],
    [ "loadResources", "class_xyz_file_reader.html#a9be695103fc15fc1f9a2be0cfe09a609", null ],
    [ "setFileName", "class_xyz_file_reader.html#af1aa60056d586e686f3b59d68f652714", null ]
];
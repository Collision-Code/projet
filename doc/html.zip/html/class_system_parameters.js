var class_system_parameters =
[
    [ "~SystemParameters", "class_system_parameters.html#aa8821b84e7993b66d83a1ce2c92b0506", null ],
    [ "getMaximalNumberThreads", "class_system_parameters.html#afa8b57261ff0cbc966dc4541d3737591", null ],
    [ "setMaximalNumberThreads", "class_system_parameters.html#a1a74c6de6cd094c376891abfff5fcf9f", null ]
];
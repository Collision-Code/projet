var dir_29d1a8289ea0e756ebeb33772a1330a8 =
[
    [ "console", "dir_dfb42eac18d18fd508d46a647fab2cf5.html", "dir_dfb42eac18d18fd508d46a647fab2cf5" ],
    [ "general", "dir_4c78ef1253b5e060148eea256f77d80f.html", "dir_4c78ef1253b5e060148eea256f77d80f" ],
    [ "gui", "dir_5bf68483ed784b620a8a1dc29dedf07d.html", "dir_5bf68483ed784b620a8a1dc29dedf07d" ],
    [ "math", "dir_aa4b2bed5d76e5460fdf68a32cbe3aca.html", "dir_aa4b2bed5d76e5460fdf68a32cbe3aca" ],
    [ "molecule", "dir_5f03fa64def9d9fed806fd59a35e69f7.html", "dir_5f03fa64def9d9fed806fd59a35e69f7" ],
    [ "observer", "dir_5af77a8201512b838ac03a88cbf0b0b0.html", "dir_5af77a8201512b838ac03a88cbf0b0b0" ],
    [ "reader", "dir_256a5f1411c419b6b3865e4a3edc640d.html", "dir_256a5f1411c419b6b3865e4a3edc640d" ],
    [ "writer", "dir_1cb8f8dd1b2e99c1fa47dc338a05952a.html", "dir_1cb8f8dd1b2e99c1fa47dc338a05952a" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainQt.cpp", "main_qt_8cpp.html", "main_qt_8cpp" ]
];
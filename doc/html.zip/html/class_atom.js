var class_atom =
[
    [ "~Atom", "class_atom.html#a36e78bb801a29c32a72d317180c5f480", null ],
    [ "getCharge", "class_atom.html#a60626a9d7d2f4449dc0d4bef34713ec0", null ],
    [ "getInitialPosition", "class_atom.html#ac2d561422a00e7e6566f638cb94ba166", null ],
    [ "getPosition", "class_atom.html#af3db0941870f8cefe61f499a98dd63c8", null ],
    [ "getSymbol", "class_atom.html#acd79e20f0bd15bc8ae3048a04ce6437c", null ],
    [ "setCharge", "class_atom.html#ad7a8c2bd6af2f63f3921ce3eb2ec6ca5", null ],
    [ "setPosition", "class_atom.html#a79abdff1ca44ec14538bbe1fee3913ec", null ],
    [ "setSymbol", "class_atom.html#a105d64ea60615d107ca4d3aa88f70a42", null ]
];
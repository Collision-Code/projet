var _c_c_frame_8cpp =
[
    [ "initializeDoubleSpinBox", "_c_c_frame_8cpp.html#a8f616a1204872ac423ac8fd51841dc92", null ],
    [ "initializeSpinBox", "_c_c_frame_8cpp.html#a84d6a13da27cc259f02b179672945c5c", null ],
    [ "launch", "_c_c_frame_8cpp.html#aab549ada8bae9514b79c7f0bfa0a1357", null ],
    [ "modifyResult", "_c_c_frame_8cpp.html#ab89f3ac4803ec783a9c44e30901c8b66", null ],
    [ "obtainRelativePath", "_c_c_frame_8cpp.html#a2c29b463cadd4649d4354442b28679c3", null ]
];
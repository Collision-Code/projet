var class_log_file_reader =
[
    [ "LogFileReader", "class_log_file_reader.html#a4a55089b62a18983e0f93a8782a60eee", null ],
    [ "~LogFileReader", "class_log_file_reader.html#a54696a63eb4ce77c120e09326fc71668", null ],
    [ "getFileName", "class_log_file_reader.html#a8193ce5f74d9bc886d90049ff7e42861", null ],
    [ "loadResources", "class_log_file_reader.html#ad3094fae405f13b69792e03982075e77", null ],
    [ "setFileName", "class_log_file_reader.html#a0f96df4faed976fbb4bb0021c8cec78d", null ]
];
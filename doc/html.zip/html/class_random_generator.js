var class_random_generator =
[
    [ "~RandomGenerator", "class_random_generator.html#adb4c6bb7e072373f374d1be417cceae0", null ],
    [ "getRandomNumber", "class_random_generator.html#ad2d362231a6a590668daaae7999e1988", null ]
];
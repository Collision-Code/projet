var class_worker =
[
    [ "doWork", "class_worker.html#ae63343b1b296a9d3ff70525d2cf5456b", null ],
    [ "finished", "class_worker.html#adfa119799838e68b671be5947a367f4a", null ]
];
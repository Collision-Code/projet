var class_file_reader =
[
    [ "~FileReader", "class_file_reader.html#a029d1ddebda388d1f0f5a99ce9acb311", null ],
    [ "getFileName", "class_file_reader.html#a00507de8a33ca6d06a64c4fb5347459d", null ],
    [ "loadResources", "class_file_reader.html#afc1197ffa55c5266b01c66a1c3d22d4a", null ],
    [ "setFileName", "class_file_reader.html#a3c9be147f5d78585f400d76408803deb", null ]
];
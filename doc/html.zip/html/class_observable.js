var class_observable =
[
    [ "Observable", "class_observable.html#af823886c69aa77b313c1d44b59fd7957", null ],
    [ "~Observable", "class_observable.html#a89d963584ab7007ee9412ebdc859f5f2", null ],
    [ "addObserver", "class_observable.html#af851f0a4c61f2acce7a270f774ad5cfb", null ],
    [ "notifyObservers", "class_observable.html#ab0f3d986ff2aaf3541fce890a3e861fd", null ],
    [ "removeObserver", "class_observable.html#a9e2076ec01893eb0bd65920c4ca9da4c", null ],
    [ "m_observers", "class_observable.html#a83bf070ae6dad2392b3e73564a8ee933", null ]
];
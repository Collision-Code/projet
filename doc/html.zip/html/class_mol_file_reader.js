var class_mol_file_reader =
[
    [ "MolFileReader", "class_mol_file_reader.html#a9135472d71700a9404a0fedb883dfb5a", null ],
    [ "~MolFileReader", "class_mol_file_reader.html#a471e33d8879d9e97629de33187023634", null ],
    [ "getFileName", "class_mol_file_reader.html#ad946d9415ee765c0e3026f9504346675", null ],
    [ "loadResources", "class_mol_file_reader.html#a903b68a4d3eab57070fb321b8e5015c6", null ],
    [ "setFileName", "class_mol_file_reader.html#a7ee1f86cac660f14a3713ce093f50cac", null ]
];
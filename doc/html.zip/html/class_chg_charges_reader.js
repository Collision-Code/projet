var class_chg_charges_reader =
[
    [ "ChgChargesReader", "class_chg_charges_reader.html#a0ae1e470a4f3dc788c5301d6808c22eb", null ],
    [ "~ChgChargesReader", "class_chg_charges_reader.html#a6d12b66194937f1f799256291aa6ffa8", null ],
    [ "getFileName", "class_chg_charges_reader.html#aee7911d2d64fc26635684c79df0a748f", null ],
    [ "loadResources", "class_chg_charges_reader.html#a290d2408d411f35e027bb88ea0ac6835", null ],
    [ "setFileName", "class_chg_charges_reader.html#a69533556b85ea9286ae67a8bbf3256b8", null ]
];
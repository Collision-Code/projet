var hierarchy =
[
    [ "Atom", "class_atom.html", [
      [ "StdAtom", "class_std_atom.html", null ]
    ] ],
    [ "AtomInformations", "class_atom_informations.html", null ],
    [ "CalculationOperator", "class_calculation_operator.html", [
      [ "StdCalculationOperator", "class_std_calculation_operator.html", [
        [ "MonoThreadCalculationOperator", "class_mono_thread_calculation_operator.html", null ],
        [ "MultiThreadCalculationOperator", "class_multi_thread_calculation_operator.html", null ]
      ] ]
    ] ],
    [ "GeometryCalculator::CalculationValues", "struct_geometry_calculator_1_1_calculation_values.html", null ],
    [ "ChargesReader", "class_charges_reader.html", [
      [ "ChgChargesReader", "class_chg_charges_reader.html", null ]
    ] ],
    [ "ExtractFactory", "class_extract_factory.html", [
      [ "StdExtractFactory", "class_std_extract_factory.html", null ]
    ] ],
    [ "ExtractResources", "class_extract_resources.html", [
      [ "StdExtractResources", "class_std_extract_resources.html", null ]
    ] ],
    [ "FileReader", "class_file_reader.html", [
      [ "LogFileReader", "class_log_file_reader.html", null ],
      [ "MfjFileReader", "class_mfj_file_reader.html", null ],
      [ "MolFileReader", "class_mol_file_reader.html", null ],
      [ "PdbFileReader", "class_pdb_file_reader.html", null ],
      [ "XyzFileReader", "class_xyz_file_reader.html", null ]
    ] ],
    [ "FileWriter", "class_file_writer.html", [
      [ "StdFileWriter", "class_std_file_writer.html", null ]
    ] ],
    [ "GeometryCalculator", "class_geometry_calculator.html", [
      [ "StdGeometryCalculator", "class_std_geometry_calculator.html", null ]
    ] ],
    [ "GlobalParameters", "class_global_parameters.html", null ],
    [ "MathLib", "class_math_lib.html", [
      [ "StdMathLib", "class_std_math_lib.html", null ]
    ] ],
    [ "Mean", "class_mean.html", [
      [ "StdMean", "class_std_mean.html", null ]
    ] ],
    [ "Molecule", "class_molecule.html", [
      [ "StdMolecule", "class_std_molecule.html", null ]
    ] ],
    [ "Observable", "class_observable.html", [
      [ "CalculationState", "class_calculation_state.html", null ],
      [ "CmdView", "class_cmd_view.html", [
        [ "StdCmdView", "class_std_cmd_view.html", null ]
      ] ]
    ] ],
    [ "Observer", "class_observer.html", [
      [ "CCFrame", "class_c_c_frame.html", null ],
      [ "ConsoleView", "class_console_view.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "CCFrame", "class_c_c_frame.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Worker", "class_worker.html", null ]
    ] ],
    [ "qt_meta_stringdata_CCFrame_t", "structqt__meta__stringdata___c_c_frame__t.html", null ],
    [ "qt_meta_stringdata_Worker_t", "structqt__meta__stringdata___worker__t.html", null ],
    [ "RandomGenerator", "class_random_generator.html", null ],
    [ "Result", "class_result.html", [
      [ "StdResult", "class_std_result.html", null ]
    ] ],
    [ "SystemParameters", "class_system_parameters.html", null ],
    [ "Vector3D", "class_vector3_d.html", null ]
];